

int mostrarArrayInt(int* array, int cantidad)
{

    int i;

        for(i=0;i<cantidad;i++)
        {
            printf("\n%d",array[i]);
        }
        printf("\n_________");

    return 0;
}

int ordenarArrayInt(int* array, int cantidad, int orden)
{
    int i;
    int j;
    int auxiliar;
    int contador;
        do{
            contador=0;
                for(j=i+1;j<cantidad;j++)
                {
                    if(array[i] > array[j] && orden==0 || array[i] < array[j] && orden==1)
                    {
                        auxiliar = array[j];
                        array[j] = array[i];
                        array[i] = auxiliar;
                        contador=1;
                    }
                }

          }while(contador==1);
    return 0;
}
