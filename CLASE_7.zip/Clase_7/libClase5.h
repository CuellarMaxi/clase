int mostrarArrayInt(int* array, int cantidad);
int ordenarArrayInt(int* array, int cantidad, int orden);
