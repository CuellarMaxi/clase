#include <stdio.h>
#include <stdlib.h>
#include "libClase5.h"

int main()
{
    int numero[1];

    printf("ingrese numero:");
    scanf("%d",numero);
    printf("%d",numero);
    return 0;
}
