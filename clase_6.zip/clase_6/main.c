#include <stdio.h>
#include <stdlib.h>
/*CADENA DE CARACTERES
*/
int main()
{
    char nombre[1];
    printf("ingrese nombre 1:");
    scanf("%s",nombre);
    printf("Su nombre es: %s",nombre);
    return 0;
}
