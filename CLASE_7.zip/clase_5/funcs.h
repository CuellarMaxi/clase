int getInt(char*,char*,int,long,long,int*);
