#include <stdio.h>
#include <stdlib.h>

int run ()
{
    int opcion=0;

    do
    {
    opcion=0;
    printf("Menu:\n");
    printf(" 1=Alta de Usuario\n");
    printf(" 2=Modificar Usuario\n");
    printf(" 3=Baja de usuario\n");
    printf(" 4=Publicar producto\n");
    printf(" 5=Modificar publicacion\n");
    scanf("%d",&opcion);

    switch (opcion)
        {
        case 1:
            //Alta De Usuario
            Alt_Usuarios();
            break;
        case 2:
            //Modificacion de usuario
            Mod_Usuario();
            break;
        case 3:
            //Baja de usuario
            Baj_Usuario();
            break;
        case 4:
            Pub_producto();
            break;
        }
        fflush(stdin);
    }while(opcion<=10);

    return 0;
}


int Alt_Usuarios(char ID[],char password[])
{
    printf("Ingrese ID:\n");
    scanf("%s",&ID);
    printf("Ingrese contrase�a:\n");
    scanf("%s",&password);
    return 0;

}

//while logged ==1 ?

int Mod_Usuario(char*ID[],char password[])
{
    char aux;
    int i;
    int Cantidad;
    printf("Ingrese ID:\n");
    scanf("%s",aux);
    for(i=0;i<Cantidad;i++)
    {
        if(aux==ID[i])
        {
            printf("modificar contrase�a");
            scanf("%s",password);
        }
    }
    return 0;
}


int Baj_Usuario()
{

    return 0;
}


int Pub_producto()
{
    char aux;
    char nombreProducto;
    char precio;
    char stock;
    printf("Ingrese nombre de producto:\n");
    scanf("%s",nombreProducto);
    printf("Ingrese precio del producto:\n");
    scanf("%s",precio);
    printf("Ingrese stock del producto:\n");
    scanf("%s",stock);

}


