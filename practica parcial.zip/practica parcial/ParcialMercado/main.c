#include <stdio.h>
#include <stdlib.h>
#include "usuarios.h"

int main()
{
    run();
}
