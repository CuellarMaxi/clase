#include <stdio.h>
#include <stdlib.h>
#include "clase9.c"

#define QTY_PERSONAS 200

/*Recivir solo nombre apellido y ID (legajo) del empleado en un array y dar de alta baja o ver la lista de empleados (switch),
  ordenar tambien con una opcion*/
typedef struct empleados
{
    char nombre[50];
    char apellido[50];
    int legajo;
}Persona;

int main ()
{
    struct Persona(nombre,apellido,legajo);
    int opcion;
    int continuar;
    float getFloat(char mensaje[]);
    char auxiliarNombreStr[50];
    char auxiliarApellidoStr[50];
    int auxiliarLegajo;

    do{
        printf("\n Menu \n opcion 1 = alta \n opcion 2 = baja \n opcion 4= cerrar \n ingrese opcion:");
        scanf("%d",&opcion);
        switch(opcion)
            case 1:
                printf("ingrese nombre");
                gets(auxiliarNombreStr[50].nombre);
                printf("ingrese apellido");
                scanf("%d",auxiliarApellidoStr[50]);
                break;
            case 2:
                break;
            case 3:
                mostrar;
                break;
            case 4:
                continuar=0;
                break;
        }while(continuar)
    return 0;
}
