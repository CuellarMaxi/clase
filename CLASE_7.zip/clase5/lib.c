int mostrarArray(int*array,int cantidad)
{
    int i;
        for(i=0;i<cantidad;i++)
        {
        printf("\n%d",array[i]);
        }
}

/*int ordenararray(int*array,int cantidad)
{
    int orden;
    int menor;
    int i=array[0];
    int b=array[1];

    if(array[0]<array[1] && array[0]<array[2])
    {
        menor=array[0];
        printf("el menor es %d",menor);
    }
    if(array[1]<array[0] && array[1]<array[2])
    {
        menor=array[1];
        printf("el menor es %d",menor);
    }
    if(array[2]<array[0] && array[2]<array[1])
    {
        menor=array[2];
        printf("el menor es %d",menor);
    }

}*/


