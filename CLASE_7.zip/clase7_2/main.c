#include <stdio.h>
#include <stdlib.h>
#include "lib.c"
#define cantidad 5


int main()
{
    int i;
    int j;
    int array[cantidad];
    for(j=0;j<cantidad;j++)
        {
            i=j;
            printf("ingrese numero");
            scanf("%d",&array[i]);
        }
    moverInt(array,1,3,0);
    mostrarArrayInt(array,cantidad);
    moverInt(array,1,3,1);
    mostrarArrayInt(array,cantidad);
    return 0;
}
