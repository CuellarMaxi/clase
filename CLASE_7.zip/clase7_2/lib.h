int mostrarArrayInt(int* array, int cantidad);
int moverInt(int* array,int bloque,int cantidad,int orden);
