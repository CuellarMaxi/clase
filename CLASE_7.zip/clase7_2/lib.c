int mostrarArrayInt(int* array, int cantidad)
{
    int i;
        for(i=0;i<cantidad;i++)
        {
            printf("%d",array[i]);
        }
        printf("\n_________\n");
    return 0;
}

int moverInt(int* array,int A, int B,int orden)
{
    int i;
    int aux;
    if(orden==0)
    {
        aux=array[A-1];
        for(i=A-1;i<B;i++)
        {
            array[i]=array[i+1];
        }
        array[B]=aux;
    }
    if(orden==1)
    {
        aux=array[A+1];
        for(i=A-1;i<B;i++)
        {
            array[i]=array[i+1];
        }

    }
    array[B]=aux;
 return 0;
}
