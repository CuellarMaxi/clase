int getInt(char*,char*,int,long,long,int*);
int Entero(char *str1);
