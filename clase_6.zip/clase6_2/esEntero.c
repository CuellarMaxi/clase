int getInt(char* msg,char* msgError,int cIntentos,long numMin,long numMax,int* result)
{
    int codError=-1;
    long auxNum;
    int intentos=cIntentos;

    do
    {
        printf("%s",msg);
        scanf("%ld",&auxNum);

        intentos--;

        if(auxNum<numMin || auxNum>numMax)
        {
            codError=-1;
            printf("%s\n",msgError);
        }
        else
            codError=0;
    }while(codError!=0 && intentos>0);

    if(intentos==0)
        codError=-1;
    else
    {
        codError=0;
        *result=auxNum;
    }

    return codError;
}
int Entero(char *str1)
{
    int i;
    for(i=0;str1[i]!='\0';i++)
    {
        if(str1[i]>'9'|| str1[i]<'0')
        {
            return 0;
        }
    }
return 1;
}
