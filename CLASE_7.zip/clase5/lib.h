int mostrarArray(int* array ,int cantidad);

//int ordenararray(int*array,int cantidad);
