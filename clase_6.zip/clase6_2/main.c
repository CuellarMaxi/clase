#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "esEntero.h"

int main()
{
    char str1[10];
    int validar;
    int val;
    printf("ingrese numero 1:");
    scanf("%s[0-9]",str1);
    validar=Entero(str1);
    if(validar==0)
    {
        printf("\nError");
    }
    else
    {
        printf("\nBien");
    }
    val= getInt(Edad,error,3,0,100);
    return 0;
}
