#include <stdio.h>
#include <stdlib.h>
#include "libClase5.h"
#include "libClase5.c"
#define QTY 4

int main()
{
    int i;
    int j;
    int arrayEnteros[QTY];
    int resultado;

    for(i=0;i<QTY;i++)
    {
        j=i;
        printf("ingrese numero");
        scanf("%d",&arrayEnteros[j]);
    }

    mostrarArrayInt(arrayEnteros,QTY);
    ordenarArrayInt(arrayEnteros,QTY,0);
    mostrarArrayInt(arrayEnteros,QTY);
    ordenarArrayInt(arrayEnteros,QTY,1);
    mostrarArrayInt(arrayEnteros,QTY);
    return 0;

}
