#include <stdio.h>
#include <stdlib.h>
#include "funcs.c"

int main()
{
    char nombre1[10];
    char nombre2[10];
    char nombre3[10];
    int res;
    int cant;
    printf("ingrese nombre 1:\n");
    scanf("%s",nombre1);
    printf("ingrese nombre 2:\n");
    scanf("%s",nombre2);
    res=strcmp(nombre2,nombre1);
    printf("\nNombre 1:%s",nombre1);
    printf("\nNombre 2:%s",nombre2);
        if (res>0)
        {
            printf("\nEl segundo nombre es mayor");
        }
        else if (res<0)
        {
            printf("\nEl primer nombre es mayor");
        }
        else
        {
            printf("\nLos nombres son iguales");
        }
    cant=strlen(nombre1);
    printf("\nCantidad:%d",cant);
    strcpy(nombre3,nombre1);
    printf("\nCopia del primer nombre:%s",nombre3);
    return 0;
}
