int getInt(char*,char*,int,long,long,int*);
int esEntero(int *str1);
