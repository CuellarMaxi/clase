#include <stdio.h>
#include <stdlib.h>
#include "lib.h"
#define empleados 10

int main()
{
    int arrayint [empleados];
    int aux;
    int i;

    for (i=0;i<empleados;i++)
    {
        printf("ingrese numero");
        scanf("%d",&aux);
        arrayint[i]=aux;
    }
    mostrarArray(arrayint,empleados);
    //ordenararray(arrayint,empleados);
    return 0;
}
/*vamos a pedirle dies numeros y enves de procesarlos. guardarlos en el arrayint
array y la cantidad maxima para mostrar*/
